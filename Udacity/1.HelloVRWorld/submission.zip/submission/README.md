Name: Chen Su
How Long: 10 minutes
One thing that I liked: Fun scenes already included
One thing that was challenging: Get familiar with the mouse interaction
